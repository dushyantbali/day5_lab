let rec productOddTailRecursive n acc =
    if n <= 1 then acc
    else productOddTailRecursive (n - 2) (acc * n)

let oddProduct = productOddTailRecursive 11 1
printfn "Product of odd numbers from 11 to 1 is %d" oddProduct
