// Generate a sequence of the first 700 positive integers
let numbers = seq { 1 .. 700 }

// Convert the sequence into a list
let numberList = Seq.toList numbers

// Filter out elements that are multiples of both 7 and 5
let filteredList = List.filter (fun x -> x % 7 = 0 && x % 5 = 0) numberList

// Sum all the filtered numbers using List.fold
let result = List.fold (+) 0 filteredList

// Example usage
printfn "The sum of all multiples of both 7 and 5 is %d" result
