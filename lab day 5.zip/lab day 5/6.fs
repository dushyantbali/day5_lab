// List of strings
let names: string list = ["James"; "Robert"; "John"; "William"; "Michael"; "David"; "Richard"]

// Filter names that contain the letter "I"
let filteredNames = List.filter (fun (name: string) -> name.Contains("i")) names

// Concatenate all filtered names using List.fold
let concatenatedNames = List.fold (+) "" filteredNames

// Example usage
printfn "Concatenated names: %s" concatenatedNames
