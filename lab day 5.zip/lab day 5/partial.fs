// Function that takes an exponent and a value, applying the exponent to the value
let power exponent value = value ** float exponent

// Partial application
let square = power 2 
let cube = power 3   

// Example usage
printfn "Square of 4: %f" (square 4.0)
printfn "Square of 5: %f" (square 5.0) 
printfn "Cube of 2: %f" (cube 2.0)  
printfn "Cube of 3: %f" (cube 3.0)  
