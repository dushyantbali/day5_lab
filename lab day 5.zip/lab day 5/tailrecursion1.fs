let productTailRecursive list =
    let rec loop acc lst =
        match lst with
        | [] -> acc
        | head :: tail -> loop (acc * head) tail
    loop 1 list 

let numbers = [1; 2; 3; 4; 5]
printfn "Product of %A is %d" numbers (productTailRecursive numbers)
